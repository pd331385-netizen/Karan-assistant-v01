package com.example.voiceassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * एक्सेसिबिलिटी सर्विस: बैक/होम, टैप, स्क्रॉल, टाइप, व्हाट्सऐप "भेजें" दबाना, नोटिफ़िकेशन पढ़ना।
 * सिर्फ़ नोटिफ़िकेशन के इवेंट सुनती है, इसलिए फ़ोन पर कोई लैग नहीं आता।
 */
class PhoneControlService : AccessibilityService() {

    companion object {
        @Volatile var instance: PhoneControlService? = null
        private val notes = ArrayDeque<String>()
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val text = e.text.joinToString(" ").trim()
        if (text.isEmpty()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (x: Exception) { pkg }
        synchronized(notes) {
            notes.addFirst("$app: $text")
            while (notes.size > 15) notes.removeLast()
        }
    }

    fun recentNotifications(): String = synchronized(notes) {
        if (notes.isEmpty()) "कोई नया नोटिफ़िकेशन नहीं मिला"
        else "हाल के नोटिफ़िकेशन: " + notes.take(5).joinToString("; ")
    }

    private fun findNode(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        root.findAccessibilityNodeInfosByText(text).firstOrNull()?.let { return it }
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 500) {
            val x = q.removeFirst(); seen++
            if (x.contentDescription?.toString()?.contains(text, ignoreCase = true) == true) return x
            for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    private fun findExact(root: AccessibilityNodeInfo, words: List<String>): AccessibilityNodeInfo? {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 500) {
            val x = q.removeFirst(); seen++
            val d = x.contentDescription?.toString()
            if (d != null && words.any { it.equals(d, ignoreCase = true) }) return x
            for (i in 0 until x.childCount) x.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null && !cur.isClickable) cur = cur.parent
        return (cur ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** स्क्रीन पर दिखते किसी शब्द/बटन पर टैप */
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = findNode(root, text) ?: return false
        return clickNode(n)
    }

    /** व्हाट्सऐप चैट खुली हो तो "भेजें" बटन दबाता है (सिर्फ़ व्हाट्सऐप की स्क्रीन पर) */
    fun clickSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return false
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val n = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (n != null && clickNode(n)) return true
        }
        val n = findExact(root, listOf("Send", "भेजें", "भेजना")) ?: return false
        return clickNode(n)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** down = true: नीचे की सामग्री देखने के लिए ऊपर की तरफ़ स्वाइप */
    fun swipe(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val from = dm.heightPixels * (if (down) 0.75f else 0.3f)
        val to = dm.heightPixels * (if (down) 0.3f else 0.75f)
        val path = Path().apply { moveTo(x, from); lineTo(x, to) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(),
            null, null)
    }
}
